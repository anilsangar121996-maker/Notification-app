MVVM Architecture
