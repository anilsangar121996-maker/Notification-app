package com.notification_reminder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.notification_reminder.database.Task;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private List<Task> tasks;

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(Task task);
    }
    
    public interface OnEditClickListener {
        void onEditClick(Task task);
    }

    private OnDeleteClickListener deleteListener;
    private OnEditClickListener editListener;

    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        this.deleteListener = listener;
    }

    public void setOnEditClickListener(OnEditClickListener listener) {
        this.editListener = listener;
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        if (tasks != null) {
            Task task = tasks.get(position);
            holder.tvTitle.setText(task.title);
            holder.tvDescription.setText(task.description);
            
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault());
            holder.tvTime.setText(sdf.format(task.timeMillis));

            holder.ivDelete.setOnClickListener(v -> {
                if (deleteListener != null) {
                    deleteListener.onDeleteClick(task);
                }
            });

            holder.ivEdit.setOnClickListener(v -> {
                if (editListener != null) {
                    editListener.onEditClick(task);
                }
            });

            // Add Animation
            android.view.animation.Animation animation = android.view.animation.AnimationUtils.loadAnimation(holder.itemView.getContext(), R.anim.item_animation_fall_down);
            holder.itemView.startAnimation(animation);
        }
    }

    @Override
    public int getItemCount() {
        return tasks != null ? tasks.size() : 0;
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDescription, tvTime;
        android.widget.ImageView ivDelete, ivEdit;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTaskTitle);
            tvDescription = itemView.findViewById(R.id.tvTaskDescription);
            tvTime = itemView.findViewById(R.id.tvTaskTime);
            ivDelete = itemView.findViewById(R.id.ivDeleteTask);
            ivEdit = itemView.findViewById(R.id.ivEditTask);
        }
    }
}
