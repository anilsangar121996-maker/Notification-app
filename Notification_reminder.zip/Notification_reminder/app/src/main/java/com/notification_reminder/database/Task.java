package com.notification_reminder.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "tasks")
public class Task {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String title;
    public String description;
    public long timeMillis;
    public boolean isCompleted;

    public Task(String title, String description, long timeMillis) {
        this.title = title;
        this.description = description;
        this.timeMillis = timeMillis;
        this.isCompleted = false;
    }
}
