package com.notification_reminder;

import android.Manifest;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.SharedPreferences;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.notification_reminder.database.AppDatabase;
import com.notification_reminder.database.Task;

import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvTasks;
    private TaskAdapter adapter;
    private AppDatabase db;
    private long selectedTimeMillis = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.getDatabase(this);

        rvTasks = findViewById(R.id.rvTasks);
        rvTasks.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter();
        rvTasks.setAdapter(adapter);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        adapter.setOnDeleteClickListener(new TaskAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(Task task) {
                 new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete Task")
                        .setMessage("Are you sure you want to delete this task?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                db.taskDao().delete(task);
                                loadTasks();
                                Toast.makeText(MainActivity.this, "Task Deleted", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            }
        });

        adapter.setOnEditClickListener(new TaskAdapter.OnEditClickListener() {
            @Override
            public void onEditClick(Task task) {
                showAddTaskDialog(task);
            }
        });

        loadTasks();

        FloatingActionButton fab = findViewById(R.id.fabAddTask);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddTaskDialog(null);
            }
        });

        ImageView ivLogout = findViewById(R.id.ivLogout);
        ivLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putBoolean("isLoggedIn", false);
                editor.apply();

                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void loadTasks() {
        List<Task> tasks = db.taskDao().getAllTasks();
        adapter.setTasks(tasks);
    }

    private void showAddTaskDialog(Task taskToEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null);
        builder.setView(view);

        final EditText etTitle = view.findViewById(R.id.etTaskTitle);
        final EditText etDescription = view.findViewById(R.id.etTaskDescription);
        Button btnSelectTime = view.findViewById(R.id.btnSelectTime);
        Button btnSave = view.findViewById(R.id.btnSaveTask);

        if (taskToEdit != null) {
            etTitle.setText(taskToEdit.title);
            etDescription.setText(taskToEdit.description);
            selectedTimeMillis = taskToEdit.timeMillis;
            
            // Format time for button
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(selectedTimeMillis);
            btnSelectTime.setText("Time set: " + cal.get(Calendar.HOUR_OF_DAY) + ":" + cal.get(Calendar.MINUTE));
            
            btnSave.setText("Update Task");
        } else {
             selectedTimeMillis = 0; // Reset for new task
             btnSave.setText("Save Task");
        }

        AlertDialog dialog = builder.create();

        btnSelectTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDateTimePicker(btnSelectTime);
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = etTitle.getText().toString();
                String desc = etDescription.getText().toString();

                if (title.isEmpty() || selectedTimeMillis == 0) {
                    Toast.makeText(MainActivity.this, "Please fill title and time", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (taskToEdit != null) {
                    // Update existing
                    taskToEdit.title = title;
                    taskToEdit.description = desc;
                    taskToEdit.timeMillis = selectedTimeMillis;
                    db.taskDao().update(taskToEdit);
                    Toast.makeText(MainActivity.this, "Task Updated", Toast.LENGTH_SHORT).show();
                } else {
                    // Create new
                    Task task = new Task(title, desc, selectedTimeMillis);
                    db.taskDao().insert(task); 
                    scheduleNotification(task);
                    Toast.makeText(MainActivity.this, "Task Saved", Toast.LENGTH_SHORT).show();
                }

                loadTasks();
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void showDateTimePicker(final Button btn) {
        final Calendar calendar = Calendar.getInstance();
        
        // Material Date Picker
        com.google.android.material.datepicker.MaterialDatePicker.Builder<Long> dateBuilder = com.google.android.material.datepicker.MaterialDatePicker.Builder.datePicker();
        dateBuilder.setTitleText("Select date");
        final com.google.android.material.datepicker.MaterialDatePicker<Long> datePicker = dateBuilder.build();

        datePicker.addOnPositiveButtonClickListener(selection -> {
            calendar.setTimeInMillis(selection);

            // Material Time Picker
            com.google.android.material.timepicker.MaterialTimePicker timePicker = new com.google.android.material.timepicker.MaterialTimePicker.Builder()
                    .setTimeFormat(com.google.android.material.timepicker.TimeFormat.CLOCK_12H)
                    .setHour(calendar.get(Calendar.HOUR_OF_DAY))
                    .setMinute(calendar.get(Calendar.MINUTE))
                    .setTitleText("Select time")
                    .setInputMode(com.google.android.material.timepicker.MaterialTimePicker.INPUT_MODE_CLOCK)
                    .build();

            timePicker.addOnPositiveButtonClickListener(v -> {
                calendar.set(Calendar.HOUR_OF_DAY, timePicker.getHour());
                calendar.set(Calendar.MINUTE, timePicker.getMinute());
                calendar.set(Calendar.SECOND, 0);

                selectedTimeMillis = calendar.getTimeInMillis();
                btn.setText("Time set: " + timePicker.getHour() + ":" + timePicker.getMinute());
            });

            timePicker.show(getSupportFragmentManager(), "tag_time");
        });

        datePicker.show(getSupportFragmentManager(), "tag_date");
    }

    private void scheduleNotification(Task task) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, NotificationReceiver.class);
        intent.putExtra("title", task.title);
        intent.putExtra("message", task.description);
        
        // Use task.timeMillis as unique ID or request code if possible, or simple random/time
        int requestCode = (int) System.currentTimeMillis(); 
        
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.timeMillis, pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, task.timeMillis, pendingIntent);
        }
        
        Toast.makeText(this, "Reminder Set!", Toast.LENGTH_SHORT).show();
    }
}