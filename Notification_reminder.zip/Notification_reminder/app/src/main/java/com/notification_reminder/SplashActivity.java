package com.notification_reminder;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                // Check if user is already logged in or needs onboarding
                SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
                boolean isFirstRun = prefs.getBoolean("isFirstRun", true);
                
                Intent intent;
                if (isFirstRun) {
                    intent = new Intent(SplashActivity.this, OnboardingActivity.class);
                } else {
                    // Check logic for login later, for now go to Login or Landing
                     // Assuming simple flow: Splash -> Login (if not logged in) -> Landing
                    intent = new Intent(SplashActivity.this, LoginActivity.class);
                }
                startActivity(intent);
                finish();
            }
        }, 2000); // 2 seconds delay
    }
}
